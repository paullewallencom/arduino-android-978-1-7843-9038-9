chapter3
==========================

Code for the third chapter of the book, dedicated to making a Bluetooh LE weather station with an Android interface

- sensors_test: an Arduino sketch to test the sensors of the project
- weather_ble: the Arduino sketch to receive commands via Bluetooth LE