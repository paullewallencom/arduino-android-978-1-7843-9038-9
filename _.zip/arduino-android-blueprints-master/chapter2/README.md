chapter2
==========================

Code for the second chapter of the book, dedicated to controlling an Arduino board using an Android phone and Bluetooth LE

- arduino_ble: the Arduino sketch to receive commands via Bluetooth LE
- arduinoBLE : the complete Android app to send and received commands to the Arduino with Adafruit Bluetooth LE Module.
