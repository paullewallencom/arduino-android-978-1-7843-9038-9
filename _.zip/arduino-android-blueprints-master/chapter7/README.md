chapter7
==========================

Code for the seventh chapter of the book, dedicated to controlling a relay via the Android voice API

- relay_ble: the Arduino sketch to receive commands via Bluetooth LE