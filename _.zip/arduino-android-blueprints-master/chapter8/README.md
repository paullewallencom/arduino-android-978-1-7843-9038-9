chapter8
==========================

Code for the eighth chapter of the book, dedicated to controlling a relay using the NFC chip inside an Android phone

- nfc_test: the Arduino sketch to test the NFC shield
- nfc_relay: the Arduino sketch to receive commands NFC