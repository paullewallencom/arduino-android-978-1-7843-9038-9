chapter9
==========================

Code for the ninth chapter of the book, dedicated to building a Bluetooth LE mobile robot controlled from Android

- robot_test: a basic Arduino sketch to test the robot
- robot_ble: the code to control the robot remotely via Bluetooth LE