chapter1
==========================

Code for the first chapter of the book, which is an introduction to Arduino & Android development.

- aREST_demo: a basic Arduino sketch that illustrates how to use the aREST Arduino library
- HelloArduino : basic Android App which guides you on how to set up your Integrated Development Environment namely Android Studio
