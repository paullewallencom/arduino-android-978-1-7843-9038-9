chapter4
==========================

Code for the fourth chapter of the book, dedicated to building a WiFi power switch & energy monitoring device controlled from Android

- switch_test: a basic Arduino sketch to test the relay & the current sensor of the power switch
- wireless_switch: the code for the WiFi switch controlled from an Android phone
