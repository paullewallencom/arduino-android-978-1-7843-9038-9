chapter10
==========================

Code for the tenth chapter of the book, dedicated to building a Bluetooth LE pulse rate sensor with Arduino Android

- pulse_rate_test: a basic Arduino sketch to test the pulse rate sensor
- pulse_rate_ble: the code to control access pulse rate data via Bluetooth LE